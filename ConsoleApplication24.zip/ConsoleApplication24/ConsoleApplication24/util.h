#pragma once
#include <string>
#include <fstream>
using namespace std;
class ReaderFile
{
ifstream file;
	int coutReadWord;
public:
	ReaderFile(string fileName);
	bool isOpen();
	bool isEOF();
	string getNextWord();
	void close();
	int getCountReadWord();
	~ReaderFile();
	
};